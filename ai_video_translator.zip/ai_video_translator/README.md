# AI Video Translator

## လိုအပ်တာ
- Python 3.10+
- FFmpeg (PATH ထဲမှာ `ffmpeg` command ရှိရမယ်)
- OpenAI API key

## Run
```bash
pip install -r requirements.txt
```

`.env.example` ကို `.env` လို့ copy လုပ်ပြီး API key ထည့်ပါ။ သို့မဟုတ် environment variable အနေနဲ့ `OPENAI_API_KEY` ထည့်ပါ။

```bash
python app.py
```

ပြီးရင် browser မှာ `http://127.0.0.1:5000` ဖွင့်ပါ။

## မှတ်ချက်
ဒီ version က MVP ပါ။ Video ကို server ထဲ upload လုပ်ပြီး audio transcription → translation → SRT → FFmpeg နဲ့ subtitle burn လုပ်ပါတယ်။ Production website အတွက် authentication, job queue, cloud storage, file cleanup, rate limits, progress updates စတာတွေ ထပ်ထည့်သင့်ပါတယ်။
