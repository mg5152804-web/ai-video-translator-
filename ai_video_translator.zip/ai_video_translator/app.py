import os, json, subprocess, uuid
from pathlib import Path
from flask import Flask, render_template, request, send_file, jsonify
from openai import OpenAI

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024

def srt_time(sec):
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def extract_audio(video, audio):
    subprocess.run([
        "ffmpeg", "-y", "-i", str(video), "-vn",
        "-ac", "1", "-ar", "16000", "-c:a", "mp3", str(audio)
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def translate_segments(client, segments, target):
    # Translate each subtitle segment while preserving one-to-one timing.
    out = []
    for seg in segments:
        text = seg["text"].strip()
        if not text:
            continue
        r = client.responses.create(
            model=os.getenv("TEXT_MODEL", "gpt-5.6-luna"),
            input=[
                {
                    "role": "system",
                    "content": (
                        "You are a subtitle translator. Translate the supplied dialogue "
                        f"naturally into {target}. Keep the meaning and tone. "
                        "Return only the translated subtitle text; do not add explanations."
                    ),
                },
                {"role": "user", "content": text},
            ],
        )
        out.append({**seg, "translated": r.output_text.strip()})
    return out

def write_srt(segments, path):
    lines = []
    for i, s in enumerate(segments, 1):
        lines += [
            str(i),
            f"{srt_time(s['start'])} --> {srt_time(s['end'])}",
            s["translated"],
            ""
        ]
    path.write_text("\n".join(lines), encoding="utf-8")

def burn_subtitles(video, srt, output):
    # libass handles subtitle rendering; use a filename with escaped path.
    sub = str(srt).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
    vf = f"subtitles='{sub}'"
    subprocess.run([
        "ffmpeg", "-y", "-i", str(video), "-vf", vf,
        "-c:a", "copy", "-c:v", "libx264", "-crf", "20",
        "-preset", "medium", str(output)
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/translate")
def translate():
    if not os.getenv("OPENAI_API_KEY"):
        return jsonify(error="OPENAI_API_KEY မသတ်မှတ်ရသေးပါ။"), 500

    file = request.files.get("video")
    target = request.form.get("target", "Burmese")
    if not file or not file.filename:
        return jsonify(error="Video ဖိုင်ရွေးပါ။"), 400

    job = uuid.uuid4().hex
    video = UPLOADS / f"{job}_{file.filename}"
    audio = UPLOADS / f"{job}.mp3"
    srt = OUTPUTS / f"{job}.srt"
    output = OUTPUTS / f"{job}_translated.mp4"
    file.save(video)

    try:
        client = OpenAI()
        extract_audio(video, audio)

        with open(audio, "rb") as f:
            tr = client.audio.transcriptions.create(
                model=os.getenv("TRANSCRIBE_MODEL", "gpt-4o-transcribe"),
                file=f,
                response_format="verbose_json",
                timestamp_granularities=["segment"],
            )

        segments = [
            {"start": float(x.start), "end": float(x.end), "text": x.text}
            for x in tr.segments
        ]
        translated = translate_segments(client, segments, target)
        write_srt(translated, srt)
        burn_subtitles(video, srt, output)

        return send_file(output, as_attachment=True, download_name="translated_video.mp4")
    except Exception as e:
        return jsonify(error=str(e)), 500
    finally:
        for p in [video, audio]:
            try: p.unlink()
            except: pass

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
